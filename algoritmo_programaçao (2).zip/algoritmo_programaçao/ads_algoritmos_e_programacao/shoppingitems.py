class ShopItem:

    def__init__(self):
    
    self.nome = ''
    self.qtd = 0
    self.valor = 0.0
    self.desconto = 0

    def retorna_valor(self):
        pass

class ShopList:

    def__init__(self):

        self.shop_list = []

    def soma_lista(self):
        total = 0 

        for item in self.shop_list:
            soma_item = item.valor * item.qtd

            desconto = soma_item * item.desconto / 100

            valor_final = soma_item - desconto

            total += valor_final

            print(f"Valor do item: {valor_final}")

            print(f"Valor total da compra: {total}")
        return total

if __name__=='__main__':

    lista_de_itens = shop_list()
    
    while True:
        item = ShopItem()

        item.nome = input('Nome: ')
        item.qtd = int(input('Quantidade: '))
        item.valor = float(input('Valor: '))
        item.desconto = 10


        
        lista_de_itens.shop_list.append(item)

        continuar = input('Quer continuar? (s/n): ')
        
        if continuar.lower() == 'n':
            break





