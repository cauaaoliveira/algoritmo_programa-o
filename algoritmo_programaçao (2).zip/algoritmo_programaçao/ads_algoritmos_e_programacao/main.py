from shoppinglib.users import user_exists, create_user, get_user_password


class App:

    def __init__(self):
        pass

    def validate_login(self, login, password):
    login = input('Digite seu nome: ')
    password = input('Digite sua senha: ')
    
    stored_password = get_user_password(login)

    if stored_password is None:
        print('Usuário não existe')
        return False
    
    if password == stored_password:
        print('Login correto')
        return True
    else:
        print('Senha incorreta')
        return False


    def register(self):
      username = ''
    while not username:
        username = input('Digite seu nome: ').strip()
        
        if user_exists(username):
            print('Já existe')
            username = ''  

    while True:
            password = input('Crie sua senha: ')

            if len(password) <8:
                print('Sua senha deve ter mais de 8 carecteres')
                continue

            tem_numero = False
            tem_especial = False

            for c in password: 
                if c >= '0' and c <= '9': 
                    tem_numero = True 
                if c in "@#$%":
                    tem_especial = True

            if not tem_numero:
                print('Precisa ter número')
                continue

            if not tem_especial:
                print('Precisa ter um carecter especial')
                continue

            break

    create_user(username, password)

    def get_login(self):
    username = input('Digite seu nome: ')
    stored_password = get_user_password(username)

    if stored_password is None:
        print('Usuário não existe')
        return

    tentativas = 3

    while tentativas > 0:
        password = input('Digite sua senha: ')

        if password == stored_password:
            print('Login correto')
            return  

        tentativas -= 1
        print(f'Senha incorreta. Tentativas restantes: {tentativas}')

    print('Acesso bloqueado')

    def start(self):
       self.register()
       self.get_login()
       self.validate_login()

app = App()
app.start()





